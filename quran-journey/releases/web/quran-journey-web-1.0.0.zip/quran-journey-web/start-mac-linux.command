#!/usr/bin/env bash
# Double-click (Mac) or run ./start-mac-linux.command. Needs PHP 8.2+.
cd "$(dirname "$0")/web" || exit 1
if ! command -v php >/dev/null 2>&1; then
  echo "PHP is not installed. On a Mac: install Homebrew (https://brew.sh) then run: brew install php"
  echo "On Ubuntu/Debian: sudo apt install php-cli php-sqlite3 php-mbstring php-curl"
  read -r -p "Press Enter to close." _; exit 1
fi
php -r 'exit(extension_loaded("pdo_sqlite") ? 0 : 1);' || { echo "PHP needs the pdo_sqlite extension."; read -r -p "Press Enter to close." _; exit 1; }
echo "The Quran Journey is running at http://localhost:8080  (close this window to stop)"
( sleep 1; (open http://localhost:8080 || xdg-open http://localhost:8080) >/dev/null 2>&1 ) &
php -S localhost:8080 -t public public/index.php
