@echo off
REM Double-click to run. Needs PHP 8.2+ (see INSTALL.txt).
cd /d "%~dp0web"
where php >nul 2>nul
if errorlevel 1 (
  echo PHP is not installed. Open PowerShell and run:  winget install PHP.PHP.8.3
  echo Then close this window and double-click start-windows.bat again.
  pause
  exit /b 1
)
for /f "delims=" %%i in ('where php') do if not defined PHPDIR set "PHPDIR=%%~dpi"
echo The Quran Journey is running at http://localhost:8080  (close this window to stop)
start "" http://localhost:8080
php -d extension_dir="%PHPDIR%ext" -d extension=pdo_sqlite -d extension=sqlite3 -d extension=mbstring -d extension=curl -d extension=openssl -S localhost:8080 -t public public/index.php
